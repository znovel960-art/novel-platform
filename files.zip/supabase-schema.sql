-- Run this in Supabase SQL Editor (Project > SQL Editor > New query)

create table novels (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  blurb text,
  author_id uuid references auth.users(id),
  status text default 'pending_review',
  reads int default 0,
  downloads int default 0,
  created_at timestamp default now()
);

create table chapters (
  id uuid primary key default gen_random_uuid(),
  novel_id uuid references novels(id) on delete cascade,
  chapter_number int not null,
  content text not null
);

create table view_events (
  id uuid primary key default gen_random_uuid(),
  novel_id uuid references novels(id),
  user_id uuid references auth.users(id),
  device_id text,
  event_type text check (event_type in ('read', 'download')),
  created_at timestamp default now(),
  unique (novel_id, user_id, device_id, event_type)
);

-- credit_read: only counts once per user+device per novel per day
create or replace function credit_read(novel_id uuid)
returns void as $$
begin
  insert into view_events (novel_id, user_id, device_id, event_type)
  values (novel_id, auth.uid(), current_setting('request.headers')::json->>'x-device-id', 'read')
  on conflict do nothing;

  update novels set reads = reads + 1 where id = novel_id;
end;
$$ language plpgsql security definer;

create or replace function credit_download(novel_id uuid)
returns void as $$
begin
  insert into view_events (novel_id, user_id, device_id, event_type)
  values (novel_id, auth.uid(), current_setting('request.headers')::json->>'x-device-id', 'download')
  on conflict do nothing;

  update novels set downloads = downloads + 1 where id = novel_id;
end;
$$ language plpgsql security definer;

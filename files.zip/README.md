# Novel Library — Setup Guide

## یہ کیا ہے
Free novel reading site جس میں authors کو ad revenue سے reads اور downloads کی بنیاد پر پیسے ملتے ہیں۔

## مرحلہ 1: کمپیوٹر پر چلانا

1. [Node.js](https://nodejs.org) انسٹال کریں (اگر پہلے سے نہیں ہے)
2. اس فولڈر میں ٹرمینل کھولیں اور یہ کمانڈ چلائیں:
   ```
   npm install
   ```
3. `.env.local.example` کو کاپی کر کے `.env.local` بنائیں اور Supabase کی values ڈالیں (مرحلہ 2 دیکھیں)
4. لوکل سرور چلائیں:
   ```
   npm run dev
   ```
5. براؤزر میں `http://localhost:3000` کھولیں

## مرحلہ 2: Supabase سیٹ اپ (database + login)

1. [supabase.com](https://supabase.com) پر مفت اکاؤنٹ بنائیں
2. نیا project بنائیں
3. بائیں طرف "SQL Editor" پر جائیں، اور `supabase-schema.sql` فائل کا پورا کوڈ پیسٹ کر کے "Run" دبائیں — یہ تمام tables اور functions بنا دے گا
4. Settings > API میں جا کر `Project URL` اور `anon public key` کاپی کریں
5. یہ values اپنی `.env.local` فائل میں ڈالیں

## مرحلہ 3: Vercel پر مفت hosting

1. اس پورے فولڈر کو [github.com](https://github.com) پر ایک نئے repository میں اپلوڈ کریں
2. [vercel.com](https://vercel.com) پر GitHub سے sign in کریں
3. "Import Project" کر کے یہی repository select کریں
4. Environment Variables میں وہی دو values ڈالیں جو `.env.local` میں تھیں
5. Deploy دبائیں — چند منٹ میں سائٹ لائیو ہو جائے گی، بالکل مفت

## ابھی کیا کام کرتا ہے
- Homepage: novels کی list (ابھی sample data، Supabase کنیکٹ ہوتے ہی asli data آئے گا)
- Reader page: 30 سیکنڈ پڑھنے کے بعد read شمار ہوتی ہے
- Upload page: نیا ناول جمع کرنے کا فارم

## ابھی کیا باقی ہے (اگلے قدم)
- Login/signup صفحہ (Supabase Auth UI سے آسانی سے بن سکتا ہے)
- Author dashboard (earnings دیکھنے کے لیے)
- Google AdSense کا اصل ad code لگانا
- JazzCash payout (شروع میں manual رہے گا)
- Device fingerprint کا اصل logic (`device_id` header بھیجنا)

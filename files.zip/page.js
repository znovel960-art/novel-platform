import { supabase } from '../lib/supabaseClient';

const sampleNovels = [
  { id: '1', title: 'آخری خط', author: 'Sana A.', reads: 12400 },
  { id: '2', title: 'شہرِ خاموش', author: 'Imran K.', reads: 8100 },
  { id: '3', title: 'دل کا قصہ', author: 'Mehwish R.', reads: 21000 },
];

async function getNovels() {
  const { data, error } = await supabase
    .from('novels')
    .select('id, title, author, reads')
    .order('reads', { ascending: false });

  if (error || !data || data.length === 0) {
    return sampleNovels;
  }
  return data;
}

export default async function HomePage() {
  const novels = await getNovels();

  return (
    <div>
      <p style={{ color: '#6B6862', fontSize: 14, marginBottom: 20 }}>
        پڑھنا مفت ہے، اپلوڈ کرنا مفت ہے
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
        {novels.map((novel) => (
          <a
            key={novel.id}
            href={`/novel/${novel.id}`}
            style={{
              display: 'block',
              padding: 16,
              borderRadius: 12,
              border: '1px solid #e5e2d8',
              textDecoration: 'none',
              color: 'inherit',
              background: '#fff',
            }}
          >
            <p style={{ fontWeight: 600, margin: '0 0 4px' }}>{novel.title}</p>
            <p style={{ fontSize: 13, color: '#6B6862', margin: '0 0 8px' }}>{novel.author}</p>
            <p style={{ fontSize: 12, color: '#8B2E2E', margin: 0 }}>{novel.reads.toLocaleString()} reads</p>
          </a>
        ))}
      </div>
    </div>
  );
}

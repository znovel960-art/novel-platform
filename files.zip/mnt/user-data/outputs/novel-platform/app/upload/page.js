'use client';

import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

export default function UploadPage() {
  const [title, setTitle] = useState('');
  const [blurb, setBlurb] = useState('');
  const [chapterText, setChapterText] = useState('');
  const [status, setStatus] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('جمع کیا جا رہا ہے...');

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setStatus('پہلے لاگ ان کریں۔');
      return;
    }

    const { error } = await supabase.from('novels').insert({
      title,
      blurb,
      author_id: user.id,
      status: 'pending_review',
    });

    if (error) {
      setStatus('کچھ غلط ہو گیا، دوبارہ کوشش کریں۔');
      return;
    }

    setStatus('جمع ہو گیا۔ نظرثانی کے بعد لائیو ہو جائے گا۔');
    setTitle('');
    setBlurb('');
    setChapterText('');
  }

  return (
    <div style={{ maxWidth: 480 }}>
      <p style={{ fontSize: 14, color: '#6B6862', marginBottom: 16 }}>
        نیا ناول اپلوڈ کریں — جمع کرنے کے بعد یہ مختصر نظرثانی سے گزرے گا۔
      </p>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <input
          placeholder="ناول کا عنوان"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          style={{ padding: 10, borderRadius: 8, border: '1px solid #d8d5c9' }}
        />
        <textarea
          placeholder="مختصر تعارف"
          value={blurb}
          onChange={(e) => setBlurb(e.target.value)}
          rows={3}
          style={{ padding: 10, borderRadius: 8, border: '1px solid #d8d5c9' }}
        />
        <textarea
          placeholder="پہلا باب یہاں لکھیں"
          value={chapterText}
          onChange={(e) => setChapterText(e.target.value)}
          rows={8}
          style={{ padding: 10, borderRadius: 8, border: '1px solid #d8d5c9' }}
        />
        <button type="submit" style={{ padding: '10px 20px', borderRadius: 8, border: 'none', background: '#8B2E2E', color: '#fff', cursor: 'pointer' }}>
          جمع کریں
        </button>
        {status && <p style={{ fontSize: 13, color: '#6B6862' }}>{status}</p>}
      </form>
    </div>
  );
}

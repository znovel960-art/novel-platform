'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '../../../lib/supabaseClient';

export default function NovelPage() {
  const params = useParams();
  const [credited, setCredited] = useState(false);

  useEffect(() => {
    // Minimum reading time check: only count the view after 30 real seconds
    // on the page. If the reader leaves earlier, nothing gets recorded.
    const timer = setTimeout(async () => {
      try {
        await supabase.rpc('credit_read', { novel_id: params.id });
        setCredited(true);
      } catch (err) {
        console.error('Could not credit read', err);
      }
    }, 30000);

    return () => clearTimeout(timer);
  }, [params.id]);

  async function handleDownload() {
    await supabase.rpc('credit_download', { novel_id: params.id });
    // Actual file download logic (signed URL from Supabase storage) goes here.
    alert('Download credited and file would download here.');
  }

  return (
    <div>
      <div style={{ background: '#fff', border: '1px solid #e5e2d8', borderRadius: 12, padding: 24 }}>
        <p style={{ fontWeight: 600, fontSize: 16, margin: '0 0 4px' }}>آخری خط — باب 1</p>
        <p style={{ fontSize: 13, color: '#6B6862', margin: '0 0 16px' }}>By Sana A.</p>
        <p style={{ fontSize: 15, lineHeight: 1.9, color: '#3a3a38', margin: 0 }}>
          رات کے سناٹے میں اس نے آخری بار وہ خط پڑھا، جو کبھی بھیجا نہیں گیا تھا۔
          کھڑکی سے آتی ہلکی روشنی میں الفاظ دھندلے ہو رہے تھے...
        </p>
      </div>
      <div style={{ marginTop: 16 }}>
        <button onClick={handleDownload} style={{ padding: '10px 20px', borderRadius: 8, border: '1px solid #8B2E2E', background: 'transparent', color: '#8B2E2E', cursor: 'pointer' }}>
          ڈاؤن لوڈ کریں
        </button>
      </div>
      <p style={{ fontSize: 12, color: '#999', marginTop: 12 }}>
        {credited ? 'یہ ریڈ شمار ہو چکا ہے' : 'صفحہ کھلا رکھیں تاکہ ریڈ شمار ہو'}
      </p>
    </div>
  );
}
